import './App.css';
import React, { useState } from 'react';
import Menu from './Components/front/Menu/Menu';
import { productlists } from './Components/back/productlists';

function App() {
  const { productItems } = productlists;
  const [cart, setCart] = useState([]);
  const addToCart = (product) => {
  const productItems = cart.find((item) => item.key === product.key);

    if (productItems) {
      console.log(productItems);
      setCart(
        cart.map((item) =>
        item.key === product.key
        ? { ...productItems, quantity: productItems.quantity + 1} : item)
      );
    }
    else{
      setCart([...cart, { ...product, quantity: 1}]);
    }
  }

  const removeFromCart = (product) => {
    
    const productItems = cart.find((item) => item.key === product.key);

    if ( productItems.quantity === 1){
      
      setCart(cart.filter((item) => item.key !== product.key));
    }

    else{
      setCart(
        cart.map((item) =>
        item.key === product.key
        
          ? { ...productItems, quantity: productItems.quantity - 1 } : item) 
        );

    }

  }

  const handleCartClearance = () => {
    setCart([]);
  }

  return (
  <div className="App">
    <Menu
    productItems={productItems} cart={cart}
    addToCart={addToCart}
    removeFromCart={removeFromCart}
    handleCartClearance={handleCartClearance}
    />
  </div>
  );
}

export default App;