import {productlists} from '../../back/productlists'
import NikeShoes from "../NikeMain/NikeShoes";
import './Nike.css'

function Nike({productItems, addToCart}) {
    return (
        <div style={{ textAlign: 'center' }}>
            <h1><i>NIKE</i> Products</h1>
            <div className="products">
                {productlists.productItems.map((prodVar, index) => {
                    return (
                        <div>
                            <NikeShoes
                                key={index}
                                img={prodVar.imgsrc}
                                name={prodVar.name}
                                price={prodVar.price}
                                type={prodVar.type}
                                addToCart={() => {addToCart(prodVar)}}
                            />
                        </div>
                    );
                })}
            </div>
        </div>
    );

}

export default Nike;