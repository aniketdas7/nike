import React from 'react';
import './Products.css'

function NikeShoes(props, product) {
    return (
        <div className=''>
            <div className='card'>
                {/* <br></br> */}
                <div className=''>
                    <img className='product-image' src={props.img} alt='' />
                </div>
                <span>{props.name}</span>
                {/* <br></br> */}
                <span>{props.type}</span>
                {/* <br></br> */}
                <span>₹ {props.price}</span>
                {/* <br></br> */}
                <br></br>
                <button className='btn' onClick={() => {props.addToCart(product)}}>ADD TO CART</button>
                <br></br>
            </div>
        </div>
    );
}

export default NikeShoes;