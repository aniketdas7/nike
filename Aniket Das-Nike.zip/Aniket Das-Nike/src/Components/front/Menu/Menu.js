import React from 'react';
import { Route, Routes, NavLink } from 'react-router-dom'

import AboutUs from '../AboutUs/AboutUs'
import Nike from '../NikeMain/Nike'
import Cart from '../Cart/Cart'
import './Menu.css';

function Menu({productItems, cart, addToCart, removeFromCart, handleCartClearance}) {
    return (
        <>
            <div>
                <h1 className='text-white bg-black text-center'>
                    <b>JUST DO IT.</b>
                </h1>
                {/* <img className='tool' src='https://www.edigitalagency.com.au/wp-content/uploads/just-do-it.-nike-logo-icon-white-text-black-background.png'></img> */}
                <div className='logo'>
                    {/* <center><h1><i>NIKE</i></h1></center> */}
                    {/* <br></br> */}
                    <img src="https://www.nicepng.com/png/detail/1-15470_logo-png-svg-vector-nike-just-do-it.png" className="logo" alt="" />
                </div>
                <center>
                    <ul className=''>
                        <li>
                            <NavLink className='text-black nav-link' to='/aboutus'>ABOUT US</NavLink>
                        </li>
                        <li>
                            <NavLink className='text-black nav-link' to='/' >PRODUCTS</NavLink>
                        </li>
                        <li>
                            <NavLink className='text-black nav-link' to='/cart'>CART</NavLink>
                        </li>
                    </ul>
                </center>
            </div>

            <Routes>
                <Route exact path='/aboutus' element={<AboutUs />} />
                <Route exact path='/cart' element={<Cart 
                cart={cart}
                addToCart={addToCart}
                removeFromCart={removeFromCart}
                handleCartClearance={handleCartClearance}
                />} />
                <Route path='/' element={
                <Nike 
                    addToCart={addToCart}
                    productItems={productItems}
                />} />
            </Routes>
        </>
    );
}

export default Menu;