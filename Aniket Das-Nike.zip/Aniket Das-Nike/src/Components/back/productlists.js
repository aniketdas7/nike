export const productlists = {
    productItems:
    [
        {
            key: 1,
            imgsrc: 'https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/53bdca6c-d7ad-478e-8509-a1d81465471e/renew-elevate-3-basketball-shoes-QT43Gj.png',
            name: 'Nike Renew Elevate 3',
            price: 7095,
            type: 'Basketball shoe'
        },
        {
            key: 2,
            imgsrc: 'https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/da968e74-40a9-44d5-9a62-a708c072fc7d/pegasus-38-road-running-shoes-Hmsj6Q.png',
            name: 'Nike Pegasus 38',
            price: 9995,
            type: 'Running shoe'
        },
        {
            key: 3,
            imgsrc: 'https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/ba98ed6b-72f7-4ba8-81a1-bb336fad67f5/air-jordan-xxxvii-low-pf-basketball-shoes-7z7ltC.png',
            name: 'Nike Air Jordan XXXVII Low PF',
            price: 16295,
            type: 'Basketball shoe'
        },
        {
            key: 4,
            imgsrc: 'https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/72323c71-8f00-452e-8908-81b1b97e6933/custom-mercurial-superfly-9-academy-by-you.png',
            name: 'Nike Zoom Mercurial Superfly 9',
            price:  11995,
            type: 'Football shoe'
        },
        {
            key: 5,
            imgsrc: 'https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/56722f56-743d-4991-9120-fc9274890cca/react-infinity-3-road-running-shoes-1W741N.png',
            name: 'Nike React Infinity 3 Premium',
            price: 14995,
            type: 'Running shoe'
        },
        {
            key: 6,
            imgsrc: 'https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5/5ace688d-0365-4775-aacd-74fde363fe55/waffle-debut-shoes-Q1dcd5.png',
            name: 'Nike Waffle Debut',
            price: 6295,
            type: 'Sneakers shoe'
        }
    ]
}